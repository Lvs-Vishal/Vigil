// Canonical Nodeframe seed data — single source of truth for the marketing
// site, the dashboard, and the AI-insights API route. Do not fork this data.
//
// This reflects the real hackathon build: 4 sensors are physically wired to
// the ESP32 (power budget caps it there); 4 more plugin manifests exist and
// are shown honestly as "not installed" — no fabricated community authors,
// no fabricated install counts anywhere in this file.
import raw from "./seed-data.json";

export type ThresholdKey = "warn_above" | "crit_above" | "warn_below" | "crit_below";
export type Status = "good" | "warning" | "critical";

export interface SeriesPoint {
  t: string;
  v: number;
}

export interface Module {
  id: string;
  slug: string;
  label: string;
  slot: string;
  sensor_chip: string;
  metric_key: string;
  unit: string;
  author: string;
  status: Status;
  latest: number;
  thresholds: Partial<Record<ThresholdKey, number>>;
  series: SeriesPoint[];
  connected_at: string;
}

export interface SystemEvent {
  t: string;
  type: string;
  severity: "info" | "warning" | "critical";
  module: string;
  message: string;
}

export interface MarketplacePlugin {
  slug: string;
  name: string;
  sensor_chip?: string;
  category: string;
  author: string;
  installed: boolean;
  description: string;
  target_slot?: string;
  metric_key?: string | null;
  unit?: string | null;
  thresholds?: Partial<Record<ThresholdKey, number>>;
}

export interface SeedData {
  generated_at: string;
  core: {
    name: string;
    firmware: string;
    uptime_hours: number;
    slots_total: number;
    slots_used: number;
  };
  modules: Module[];
  events: SystemEvent[];
  marketplace: MarketplacePlugin[];
}

export const seed = raw as unknown as SeedData;

// Fixed categorical series order — one hue per INSTALLED module, in slot
// order. Keep identical everywhere a module gets a chart color.
export const SERIES_COLORS = [
  "var(--series-1)",
  "var(--series-2)",
  "var(--series-3)",
  "var(--series-4)",
  "var(--series-5)",
  "var(--series-6)",
  "var(--series-7)",
  "var(--series-8)",
] as const;

const MODULE_ORDER = ["sound-level", "ambient-light", "temperature", "proximity"] as const;

export function seriesColorFor(slug: string): string {
  const idx = MODULE_ORDER.indexOf(slug as (typeof MODULE_ORDER)[number]);
  return SERIES_COLORS[idx === -1 ? 0 : idx];
}

export function modulesInSlotOrder(): Module[] {
  return [...seed.modules].sort((a, b) => (a.slot < b.slot ? -1 : 1));
}

export function fmtNumber(n: number): string {
  if (Math.abs(n) >= 1000) return n.toLocaleString(undefined, { maximumFractionDigits: 0 });
  if (Number.isInteger(n)) return String(n);
  return n.toFixed(n < 10 ? 2 : 1);
}

export function uptimeLabel(hours: number): string {
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  const rem = Math.round(hours % 24);
  return `${days}d ${rem}h`;
}

export interface DashboardStats {
  activeModules: number;
  totalSlots: number;
  openAlerts: number;
  warningCount: number;
  criticalCount: number;
  avgSamplesPerHour: number;
  uptime: string;
}

export function computeStats(): DashboardStats {
  const modules = seed.modules;
  const warningCount = modules.filter((m) => m.status === "warning").length;
  const criticalCount = modules.filter((m) => m.status === "critical").length;
  return {
    activeModules: modules.length,
    totalSlots: seed.core.slots_total,
    openAlerts: warningCount + criticalCount,
    warningCount,
    criticalCount,
    avgSamplesPerHour: 30, // one sample every 2 minutes
    uptime: uptimeLabel(seed.core.uptime_hours),
  };
}

// Marketing-site stats — plain facts about the running demo. No fabricated
// customer/testimonial/install-count data anywhere.
export function marketingStats() {
  const installed = seed.marketplace.filter((p) => p.installed).length;
  const readyToInstall = seed.marketplace.filter((p) => !p.installed).length;
  return {
    modulesLive: seed.modules.length,
    slotsTotal: seed.core.slots_total,
    pluginsInMarketplace: seed.marketplace.length,
    pluginsInstalled: installed,
    readyToInstall,
  };
}

// Flagged modules right now — the input to the AI-insights feature and to
// any "needs attention" UI. A module is "flagged" if it's warning/critical.
export function flaggedModules(): Module[] {
  return seed.modules.filter((m) => m.status !== "good");
}
