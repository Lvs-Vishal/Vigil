# Nodeframe — web app

The marketing site and operator dashboard for [Nodeframe](../readme.md), a
modular sensor platform. Next.js 16 (App Router), TypeScript, Tailwind v4,
React 19.

```bash
npm install
npm run dev
```

- `http://localhost:3000` — marketing landing page
- `http://localhost:3000/dashboard` — operator console

`npm run build && npm run start` runs the production build. See the
[repo root README](../readme.md) for the project's architecture, plugin
manifest spec, and backend setup — this file only covers the web app itself.

Fonts (Archivo, IBM Plex Sans, IBM Plex Mono) are self-hosted via
`@fontsource`, so there's no build- or run-time dependency on Google's font
CDN. All content is driven by `lib/data.ts` / `lib/seed-data.json` — there is
no live backend wired up yet; swapping in real Supabase reads means
replacing the imports in `lib/data.ts`, not touching the components.
