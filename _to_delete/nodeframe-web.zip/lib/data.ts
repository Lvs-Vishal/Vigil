// Canonical Nodeframe seed data — single source of truth for both the
// marketing site and the dashboard. Do not fork this data; import from here.
import raw from "./seed-data.json";

export type ThresholdKey = "warn_above" | "crit_above" | "warn_below" | "crit_below";
export type Status = "good" | "warning" | "critical";

export interface SeriesPoint {
  t: string;
  v: number;
  v2?: number;
}

export interface ScanEvent {
  t: string;
  card_uid: string;
  user_name: string;
  authorized: boolean;
}

export interface Module {
  id: string;
  slug: string;
  label: string;
  slot: string;
  sensor_chip: string;
  metric_key?: string;
  unit?: string;
  secondary_metric_key?: string;
  secondary_unit?: string;
  author: string;
  official: boolean;
  status: Status;
  latest?: number;
  thresholds?: Partial<Record<ThresholdKey, number>>;
  series?: SeriesPoint[];
  scans?: ScanEvent[];
  connected_at: string;
}

export interface SystemEvent {
  t: string;
  type: string;
  severity: "info" | "warning" | "critical";
  module: string;
  message: string;
}

export interface MarketplacePlugin {
  slug: string;
  name: string;
  sensor_chip?: string;
  category: string;
  author: string;
  version: string;
  installs: number | null;
  official: boolean;
  installed: boolean;
  description: string;
}

export interface SeedData {
  generated_at: string;
  core: {
    name: string;
    firmware: string;
    uptime_hours: number;
    slots_total: number;
    slots_used: number;
  };
  modules: Module[];
  events: SystemEvent[];
  marketplace: MarketplacePlugin[];
}

export const seed = raw as unknown as SeedData;

// Fixed categorical series order — keep identical everywhere a module gets a
// chart color, per the dataviz palette (blue, copper, teal, yellow, magenta,
// violet, red, light-blue).
export const SERIES_COLORS = [
  "var(--series-1)",
  "var(--series-2)",
  "var(--series-3)",
  "var(--series-4)",
  "var(--series-5)",
  "var(--series-6)",
  "var(--series-7)",
  "var(--series-8)",
] as const;

const MODULE_ORDER = [
  "ambient-climate",
  "gas-level",
  "proximity",
  "access-control",
  "ambient-light",
  "vibration",
  "air-quality",
  "soil-moisture",
] as const;

export function seriesColorFor(slug: string): string {
  const idx = MODULE_ORDER.indexOf(slug as (typeof MODULE_ORDER)[number]);
  return SERIES_COLORS[idx === -1 ? 0 : idx];
}

export function modulesInSlotOrder(): Module[] {
  return [...seed.modules].sort((a, b) => (a.slot < b.slot ? -1 : 1));
}

export function fmtNumber(n: number): string {
  if (Math.abs(n) >= 1000) return n.toLocaleString(undefined, { maximumFractionDigits: 0 });
  if (Number.isInteger(n)) return String(n);
  return n.toFixed(n < 10 ? 2 : 1);
}

export function uptimeLabel(hours: number): string {
  const days = Math.floor(hours / 24);
  const rem = Math.round(hours % 24);
  return `${days}d ${rem}h`;
}

export interface DashboardStats {
  activeModules: number;
  totalModules: number;
  openAlerts: number;
  warningCount: number;
  criticalCount: number;
  avgSamplesPerHour: number;
  uptime: string;
}

export function computeStats(): DashboardStats {
  const modules = seed.modules;
  const warningCount = modules.filter((m) => m.status === "warning").length;
  const criticalCount = modules.filter((m) => m.status === "critical").length;
  return {
    activeModules: modules.length,
    totalModules: seed.core.slots_total,
    openAlerts: warningCount + criticalCount,
    warningCount,
    criticalCount,
    avgSamplesPerHour: 30, // one sample every 2 minutes
    uptime: uptimeLabel(seed.core.uptime_hours),
  };
}

// Marketing-site stats — plain facts about the running demo, no fabricated
// customer/testimonial data.
export function marketingStats() {
  const installed = seed.marketplace.filter((p) => p.installed).length;
  const community = seed.modules.filter((m) => !m.official).length;
  return {
    modulesLive: seed.modules.length,
    slotsTotal: seed.core.slots_total,
    pluginsInMarketplace: seed.marketplace.length,
    pluginsInstalled: installed,
    communityModules: community,
  };
}
