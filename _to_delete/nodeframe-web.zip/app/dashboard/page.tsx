import type { Metadata } from "next";
import { DashboardApp } from "@/components/dashboard/DashboardApp";

export const metadata: Metadata = {
  title: "Dashboard",
  description: "Live operator console for a Nodeframe Core Hub — module readouts, activity log, and the plugin marketplace.",
};

export default function DashboardPage() {
  return <DashboardApp />;
}
