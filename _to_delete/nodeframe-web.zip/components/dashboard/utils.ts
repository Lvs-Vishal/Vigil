// Pure helpers for the dashboard route: time formatting, the mean-reverting
// random-walk simulation, threshold-based status, and log merging. These are
// dashboard-only presentation/simulation concerns (not canonical data), so
// they live here rather than in the shared `@/lib/data` module.
import type { Module, ScanEvent, SeriesPoint, Status, SystemEvent } from "@/lib/data";

/** A module's mutable runtime state, seeded from `@/lib/data` and advanced
 * in place by the live simulation. `def` stays the immutable seed record. */
export interface ModuleRuntime {
  def: Module;
  series: SeriesPoint[] | null;
  status: Status;
  latest?: number;
}

export const MODULE_ORDER = [
  "ambient-climate",
  "gas-level",
  "proximity",
  "access-control",
  "ambient-light",
  "vibration",
  "air-quality",
  "soil-moisture",
] as const;

export const METRIC_LABEL: Record<string, string> = {
  "ambient-climate": "TEMP",
  "gas-level": "GAS PPM",
  proximity: "DISTANCE",
  "ambient-light": "LUX",
  vibration: "VIBRATION",
  "air-quality": "CO₂",
  "soil-moisture": "SOIL MOISTURE",
};

function round(v: number, d: number): number {
  const m = Math.pow(10, d);
  return Math.round(v * m) / m;
}

function pad2(n: number): string {
  return n < 10 ? "0" + n : "" + n;
}

export function fmtClock(d: Date): string {
  return `${pad2(d.getUTCHours())}:${pad2(d.getUTCMinutes())}:${pad2(d.getUTCSeconds())}`;
}

export function fmtClockShort(iso: string): string {
  const d = new Date(iso);
  return `${pad2(d.getUTCHours())}:${pad2(d.getUTCMinutes())}`;
}

const MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];

export function fmtDateLabel(d: Date): string {
  return `${MONTHS[d.getUTCMonth()]} ${d.getUTCDate()}, ${d.getUTCFullYear()} UTC`;
}

export function agoLabel(iso: string, now: Date): string {
  const ms = now.getTime() - new Date(iso).getTime();
  const mins = Math.floor(ms / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ${mins % 60}m ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ${hrs % 24}h ago`;
}

export function agoDays(iso: string, now: Date): string {
  const ms = now.getTime() - new Date(iso).getTime();
  const days = Math.floor(ms / 86400000);
  if (days < 1) return "today";
  return `${days}d ago`;
}

/* ============ threshold-based status ============ */
export function computeStatus(value: number, thresholds?: Module["thresholds"]): Status {
  if (!thresholds) return "good";
  if (thresholds.crit_above != null && value >= thresholds.crit_above) return "critical";
  if (thresholds.crit_below != null && value <= thresholds.crit_below) return "critical";
  if (thresholds.warn_above != null && value >= thresholds.warn_above) return "warning";
  if (thresholds.warn_below != null && value <= thresholds.warn_below) return "warning";
  return "good";
}

export const STATUS_RANK: Record<Status, number> = { good: 0, warning: 1, critical: 2 };

export function overallStatus(statuses: Status[]): Status {
  let worst: Status = "good";
  statuses.forEach((s) => {
    if (STATUS_RANK[s] > STATUS_RANK[worst]) worst = s;
  });
  return worst;
}

export interface ChartThreshold {
  value: number;
  label: string;
  status: "warning" | "critical";
}

export function thresholdsFor(m: Module): ChartThreshold[] {
  const t = m.thresholds;
  if (!t) return [];
  const arr: ChartThreshold[] = [];
  if (t.warn_above != null) arr.push({ value: t.warn_above, label: "WARN " + t.warn_above, status: "warning" });
  if (t.crit_above != null) arr.push({ value: t.crit_above, label: "CRIT " + t.crit_above, status: "critical" });
  if (t.warn_below != null) arr.push({ value: t.warn_below, label: "WARN " + t.warn_below, status: "warning" });
  if (t.crit_below != null) arr.push({ value: t.crit_below, label: "CRIT " + t.crit_below, status: "critical" });
  return arr;
}

/* ============ live-simulation config ============ */
export interface SimAxisConfig {
  step: number;
  reversion: number;
  min?: number;
  max?: number;
  decimals: number;
}

export interface SimConfig extends Partial<SimAxisConfig> {
  drift?: boolean;
  decimals: number;
  v2?: SimAxisConfig;
}

export const SIM_CFG: Record<string, SimConfig> = {
  "ambient-climate": {
    step: 0.32,
    reversion: 0.1,
    min: 12,
    max: 34,
    decimals: 2,
    v2: { step: 0.9, reversion: 0.1, min: 22, max: 72, decimals: 2 },
  },
  "gas-level": { step: 11, reversion: 0.14, min: 70, max: 340, decimals: 1 },
  proximity: { step: 9, reversion: 0.08, min: 18, max: 235, decimals: 2 },
  "ambient-light": { step: 26, reversion: 0.1, min: 40, max: 640, decimals: 2 },
  vibration: { step: 0.012, reversion: 0.16, min: 0, max: 0.16, decimals: 2 },
  "air-quality": { step: 16, reversion: 0.1, min: 440, max: 900, decimals: 2 },
  "soil-moisture": { drift: true, min: 3.5, decimals: 2 },
};

/** Mean-reverting random walk, continuing from the series' last real value. */
export function nextValue(seriesVals: number[], cfg: SimAxisConfig | SimConfig): number {
  const last = seriesVals[seriesVals.length - 1];
  if ("drift" in cfg && cfg.drift) {
    const step = 0.04 + Math.random() * 0.14;
    const noise = (Math.random() - 0.5) * 0.06;
    let v = last - step + noise;
    if (cfg.min != null) v = Math.max(cfg.min, v);
    return round(v, cfg.decimals);
  }
  const recent = seriesVals.slice(-8);
  const avg = recent.reduce((a, b) => a + b, 0) / recent.length;
  const step = cfg.step ?? 1;
  const reversion = cfg.reversion ?? 0;
  const noise2 = (Math.random() - 0.5) * 2 * step;
  const pull = (avg - last) * reversion;
  let v2 = last + noise2 + pull;
  if (cfg.min != null) v2 = Math.max(cfg.min, v2);
  if (cfg.max != null) v2 = Math.min(cfg.max, v2);
  return round(v2, cfg.decimals);
}

/** Advances every continuous module's series by one synthetic sample,
 * mean-reverting from its own last real value. Access Control (scan-based,
 * no series) is left untouched, matching the reference build's tick. */
export function tickModules(prev: ModuleRuntime[]): ModuleRuntime[] {
  return prev.map((m) => {
    if (m.def.slug === "access-control") return m;
    const cfg = SIM_CFG[m.def.slug];
    if (!cfg || !m.series || m.series.length === 0) return m;

    const vals = m.series.map((p) => p.v);
    const nextV = nextValue(vals, cfg);
    const lastT = new Date(m.series[m.series.length - 1].t);
    const nextT = new Date(lastT.getTime() + 2 * 60000);
    const point: SeriesPoint = { t: nextT.toISOString(), v: nextV };
    if (cfg.v2) {
      const vals2 = m.series.map((p) => p.v2 ?? 0);
      point.v2 = nextValue(vals2, cfg.v2);
    }

    let series = [...m.series, point];
    if (series.length > 90) series = series.slice(series.length - 90);

    return {
      ...m,
      series,
      latest: nextV,
      status: computeStatus(nextV, m.def.thresholds),
    };
  });
}

/* ============ activity log ============ */
export interface LogItem {
  t: string;
  severity: "info" | "warning" | "critical";
  module: string;
  type: string;
  message: string;
}

export function buildMergedLog(events: SystemEvent[], modules: Module[]): LogItem[] {
  const items: LogItem[] = events.map((e) => ({
    t: e.t,
    severity: e.severity,
    module: e.module,
    type: e.type,
    message: e.message,
  }));
  modules.forEach((m) => {
    if (!m.scans) return;
    m.scans.forEach((s: ScanEvent) => {
      items.push({
        t: s.t,
        severity: s.authorized ? "info" : "warning",
        module: "Access Control",
        type: "access",
        message: s.authorized
          ? `Badge ${s.card_uid} (${s.user_name}) granted access.`
          : `Unrecognized badge ${s.card_uid} presented — access denied.`,
      });
    });
  });
  items.sort((a, b) => new Date(b.t).getTime() - new Date(a.t).getTime());
  return items;
}
