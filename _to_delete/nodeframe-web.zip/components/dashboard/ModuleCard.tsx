import { fmtNumber } from "@/lib/data";
import { SparkChart } from "./SparkChart";
import { ScanList } from "./ScanList";
import { StatusPill } from "./StatusPill";
import { METRIC_LABEL, agoDays, thresholdsFor } from "./utils";
import type { ModuleRuntime } from "./utils";

// Only these single-metric modules show their threshold lines on-chart in
// the reference build; the rest carry thresholds for status color only.
const SHOW_THRESHOLDS = new Set(["gas-level", "soil-moisture"]);

export function ModuleCard({ runtime, color, now }: { runtime: ModuleRuntime; color: string; now: Date }) {
  const { def, series, status, latest } = runtime;
  const isDual = Boolean(def.secondary_metric_key);
  const isAccessControl = def.slug === "access-control";

  return (
    <article className="relative flex flex-col gap-3 rounded-[10px] border border-border bg-surface px-[18px] pt-4 pb-3.5 transition-colors duration-150 hover:border-border-strong hover:bg-surface-2">
      <div className="flex items-start justify-between gap-2.5">
        <div className="flex items-center gap-2">
          <span className="flex-none rounded border border-border-strong bg-surface-2 px-1.5 py-0.5 font-mono text-[11px] font-medium text-ink">
            {def.slot}
          </span>
          <div className="flex min-w-0 flex-col gap-0.5">
            <span className="text-[14.5px] font-semibold text-ink">{def.label}</span>
            <span className="font-mono text-[11px] text-ink-muted">{def.sensor_chip}</span>
          </div>
        </div>
        <div className="flex flex-col items-end gap-0.5">
          <StatusPill status={status} label={status.toUpperCase()} />
          <span className="rounded-[3px] border border-border px-1 py-px font-mono text-[9.5px] tracking-[0.06em] text-ink-muted uppercase whitespace-nowrap">
            {def.official ? "OFFICIAL" : "COMMUNITY"}
          </span>
        </div>
      </div>

      {isAccessControl ? (
        <ScanList module={def} now={now} />
      ) : (
        <>
          <div className="flex flex-wrap items-baseline gap-2">
            <span className="font-mono text-[26px] font-medium tabular-nums text-ink">{fmtNumber(latest ?? 0)}</span>
            <span className="font-mono text-[12px] text-ink-secondary">{def.unit}</span>
            {isDual && series && series.length > 0 && (
              <span className="ml-auto text-right font-mono text-[12px] text-ink-secondary">
                <b className="font-medium tabular-nums text-ink">{fmtNumber(series[series.length - 1].v2 ?? 0)}</b> {def.secondary_unit}
              </span>
            )}
          </div>

          {isDual ? (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <div className="mb-1 font-mono text-[10px] tracking-[0.05em] text-ink-muted uppercase">TEMPERATURE (°C)</div>
                <SparkChart
                  points={(series ?? []).map((p) => ({ t: p.t, v: p.v }))}
                  color={color}
                  unit="°C"
                  thresholds={thresholdsFor(def)}
                  ariaLabel={`${def.label} temperature over time`}
                />
              </div>
              <div>
                <div className="mb-1 font-mono text-[10px] tracking-[0.05em] text-ink-muted uppercase">HUMIDITY (%RH)</div>
                <SparkChart
                  points={(series ?? []).map((p) => ({ t: p.t, v: p.v2 ?? 0 }))}
                  color={color}
                  unit="%RH"
                  ariaLabel={`${def.label} humidity over time`}
                />
              </div>
            </div>
          ) : (
            <div>
              <div className="mb-1 font-mono text-[10px] tracking-[0.05em] text-ink-muted uppercase">
                {(METRIC_LABEL[def.slug] || "READING") + ` (${def.unit})`}
              </div>
              <SparkChart
                points={(series ?? []).map((p) => ({ t: p.t, v: p.v }))}
                color={color}
                unit={def.unit ?? ""}
                thresholds={SHOW_THRESHOLDS.has(def.slug) ? thresholdsFor(def) : []}
                ariaLabel={`${def.label} over time`}
                heightClassName="h-[118px]"
              />
            </div>
          )}

          <div className="mt-0.5 flex items-center justify-between border-t border-border pt-0.5 font-mono text-[10.5px] text-ink-muted">
            <span>{def.author || "nodeframe-core"}</span>
            <span>connected {agoDays(def.connected_at, now)}</span>
          </div>
        </>
      )}
    </article>
  );
}
