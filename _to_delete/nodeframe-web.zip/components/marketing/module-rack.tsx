import { modulesInSlotOrder, seriesColorFor } from "@/lib/data";

// Stylized hero visual: a rack of module bays matching the real slot groups
// (A1-A4, B1-B3, C1). This mirrors the live data honestly — all eight bays
// are seated, matching the "8/8 modules running" stat directly below it. The
// "swap it for anything" pitch is carried by the copy ("any slot accepts any
// plugin"), not by faking an open bay the demo doesn't actually have.
export function ModuleRack() {
  const modules = modulesInSlotOrder();

  return (
    <div
      className="rounded-lg border border-border bg-surface p-4"
      aria-label="Nodeframe module rack: all eight bays seated with an active sensor module"
    >
      <div className="mb-3 flex items-center justify-between">
        <span className="font-mono text-[0.68rem] uppercase tracking-wider text-ink-muted">
          Core hub
        </span>
        <span className="flex items-center gap-1.5 font-mono text-[0.68rem] text-teal">
          <span className="live-dot h-1.5 w-1.5 rounded-full bg-teal" />
          online
        </span>
      </div>

      <div className="grid grid-cols-4 gap-2.5">
        {modules.map((m) => {
          const color = seriesColorFor(m.slug);
          return (
            <div
              key={m.slot}
              className="group relative flex aspect-square flex-col items-center justify-center gap-2 rounded-md border border-border bg-surface-2 transition-colors"
            >
              <span className="absolute left-1.5 top-1.5 font-mono text-[0.6rem] tracking-wide text-ink-muted">
                {m.slot}
              </span>

              <span
                className="chip-glow h-3 w-3 rounded-[3px]"
                style={{ background: color, boxShadow: `0 0 0 3px ${color}22` }}
              />
              <span className="font-mono text-[0.55rem] uppercase tracking-wider text-ink-secondary">
                seated
              </span>
            </div>
          );
        })}
      </div>

      <p className="mt-3 font-mono text-[0.72rem] leading-relaxed text-ink-muted">
        Eight bays, one bus. Any bay accepts any plugin — swap one out and it
        just shows up.
      </p>

      <style>{`
        @media (prefers-reduced-motion: no-preference) {
          .chip-glow {
            animation: chip-pulse 2.6s ease-in-out infinite;
          }
          .live-dot {
            animation: chip-pulse 2.2s ease-in-out infinite;
          }
          @keyframes chip-pulse {
            0%, 100% { filter: brightness(1); opacity: 1; }
            50% { filter: brightness(1.35); opacity: 0.85; }
          }
        }
      `}</style>
    </div>
  );
}
